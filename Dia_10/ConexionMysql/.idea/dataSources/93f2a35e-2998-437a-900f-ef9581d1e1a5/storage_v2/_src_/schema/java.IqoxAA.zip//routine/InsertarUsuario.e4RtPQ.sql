create procedure InsertarUsuario(IN nombre varchar(20), IN apellido varchar(20), IN telefono varchar(20))
begin
  insert into usuario (nombre, apellido, telefono) VALUES (nombre, apellido, telefono);
end;

