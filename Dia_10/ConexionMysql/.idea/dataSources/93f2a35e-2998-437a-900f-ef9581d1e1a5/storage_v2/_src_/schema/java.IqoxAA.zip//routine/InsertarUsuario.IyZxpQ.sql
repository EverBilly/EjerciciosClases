create procedure InsertarUsuario(OUT nombre varchar(20), OUT apellido varchar(20), OUT telefono varchar(20))
begin
  insert into usuario values (nombre, apellido, telefono);
end;

