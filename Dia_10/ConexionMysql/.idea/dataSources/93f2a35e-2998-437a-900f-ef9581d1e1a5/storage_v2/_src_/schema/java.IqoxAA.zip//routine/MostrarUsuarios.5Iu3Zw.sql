create procedure MostrarUsuarios(IN id_b int)
BEGIN
  SELECT nombre, apellido, telefono, id
  FROM usuario
  WHERE id_b = id;
END;

