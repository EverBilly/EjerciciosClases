create procedure MostrarUsuarios()
BEGIN
  SELECT nombre, apellido, telefono, id
  FROM usuario;
END;

