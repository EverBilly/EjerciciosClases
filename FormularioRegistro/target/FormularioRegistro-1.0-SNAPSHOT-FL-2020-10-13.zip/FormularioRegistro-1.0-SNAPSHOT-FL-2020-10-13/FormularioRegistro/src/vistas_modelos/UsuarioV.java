package vistas_modelos;

import org.apache.commons.dbutils.QueryRunner;

import javax.naming.NamingException;
import javax.sql.CommonDataSource;
import javax.sql.DataSource;

public class UsuarioV {

    private DataSource dataSource;
    private QueryRunner queryRunner;
    private static UsuarioV usuarioV;

    private String SQL_INSERT = "insert into usuario (nombre, apellido, telefono)" +
                                "            values (?, ?, ?)";
    private String SQL_SELECT = "select * from usuario";

//    public UsuarioV() throws NamingException {
//        this.dataSource = Commons;
//    }
    public static UsuarioV getInstance() throws NamingException {
        if(usuarioV == null) {
            usuarioV = new UsuarioV();
        }
        return usuarioV;
    }
}
